const fs = require("fs");
const config = require("./babel.config");
const code = fs.readFileSync("./output.js");
const res = require("@babel/core").transform(code, config);
console.log(res.code);
