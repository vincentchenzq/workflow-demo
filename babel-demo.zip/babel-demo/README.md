### decorator

<details open>
    <summary>背景</summary>
大家晚上好，我们晚上的主题是 `decorator`，这个`decorator`当前是处于 `stg2`，但是本文的背景是源于我入职平安的时候一道的面试题

> es6 中你用过什么特性

<details >
    <summary>回答</summary>

- async/await
- Array.prototype.includes()
- dynamic-import
- Optional chaining
- ...

这些是不是 es6 的?

</details>

</details>

### tc39

[tc39 的 github 地址](https://github.com/tc39/proposals)

<details>
    <summary>stg</summary>

Stage 0: strawman

- 一种推进 ECMAScript 发展的自由形式，任何 TC39 成员，或者注册为 TC39 贡献者的会员，都可以提交

Stage 1: proposal

该阶段产生一个正式的提案。

- 确定一个带头人来负责该提案，带头人或者联合带头人必须是 TC39 的成员。
- 描述清楚要解决的问题，解决方案中必须包含例子，API 以及关于相关的语义和算法。
- 潜在问题也应该指出来，例如与其他特性的关系，实现它所面临的挑战。
- polyfill 和 demo 也是必要的。

Stage 2: draft

草案是规范的第一个版本，与最终标准中包含的特性不会有太大差别。

草案之后，原则上只接受增量修改。

- 草案中包含新增特性语法和语义的，尽可能的完善的形式说明，允许包含一些待办事项或者占位符。
- 必须包含 2 个实验性的具体实现，其中一个可以是用转译器实现的，例如 Babel。

Stage 3: candidate

候选阶段，获得具体实现和用户的反馈。

此后，只有在实现和使用过程中出现了重大问题才会修改。

- 规范文档必须是完整的，评审人和 ECMAScript 的编辑要在规范上签字。
- 至少要有两个符合规范的具体实现。

Stage 4: finished

已经准备就绪，该特性会出现在年度发布的规范之中。

- 通过 Test 262 的验收测试。
- 有 2 个通过测试的实现，以获取使用过程中的重要实践经验。
- ECMAScript 的编辑必须规范上的签字。

但是 stg4 到浏览器厂商/nodejs 正式实现的时间需要更长的时间

</details>

<details>
    <summary>ES6新特性（2015）</summary>
    
ES6的特性比较多，在 ES5 发布近 6 年（2009-11 至 2015-6）之后才将其标准化。两个发布版本之间时间跨度很大，所以ES6中的特性比较多。 在这里列举几个常用的：

- 类
- 模块化
- 箭头函数
- 函数参数默认值
- 模板字符串
- 解构赋值
- 延展操作符(数组)
- 对象属性简写

```javascript
const name = "Vincent";
const age = 18;
const city = "Shenzhen";

const student = {
  name,
  age,
  city,
};
console.log(student); //{name: "Vincent", age: 18, city: "Shenzhen"}
```

- Promise
- Let 与 Const
- Set
- Map

<details>
    <summary>LRU算法</summary>

`keep-alive`缓存淘汰算法--`LRU 算法`
LRU（Least recently used，最近最少使用）算法
![LRU](./imgs/1.png)

Object 和 Map 的区别

![Object和Map](./imgs/2.png)

</details>

</details>

<details>
    <summary>ES7新特性（2016）</summary>

- Array.prototype.includes()
- 指数操作符

```javascript
console.log(2 ** 10);
console.log(Math.pow(2, 10)); // 输出1024
```

</details>

<details>
    <summary>ES8新特性（2017）</summary>

在这里列举几个常用的

- async/await
- Object.values()
- Object.entries()
- 函数参数列表结尾允许逗号
<!--
- String padding: padStart()和 padEnd()，填充字符串达到当前长度
- Object.getOwnPropertyDescriptors()
- ShareArrayBuffer 和 Atomics 对象，用于从共享内存位置读取和写入 -->

</details>

<details>
    <summary>ES9新特性（2018）</summary>

在这里列举几个常用的

- Promise.finally()
- Rest/Spread(对象)

</details>
<details>
    <summary>ES10新特性（2019）</summary>

在这里列举几个常用的

- 新增了 Array 的 flat()方法和 flatMap()方法
- String.prototype.matchAll
- 新的基本数据类型 BigInt
<details>
    <summary>flat</summary>

```javascript
// 深度优先
var arr1 = [1, 2, [3, 4]];
arr1.flat();
// [1, 2, 3, 4]

var arr2 = [1, 2, [3, 4, [5, 6]]];
arr2.flat();
// [1, 2, 3, 4, [5, 6]]

var arr3 = [1, 2, [3, 4, [5, 6]]];
arr3.flat(2);
// [1, 2, 3, 4, 5, 6]

//使用 Infinity 作为深度，展开任意深度的嵌套数组
arr3.flat(Infinity);
// [1, 2, 3, 4, 5, 6]
```

</details>

<details>
    <summary>catch</summary>

```javascript
try {
} catch (e) {}

try {
} catch {}
```

</details>

</details>

</details>

<details>
    <summary>ES11新特性(2020)</summary>

- Promise.allSettled
- 可选链（Optional chaining）
- 空值合并运算符（Nullish coalescing Operator）
- dynamic-import

<details>
    <summary>可选链</summary>

```javascript
const isExistName = user && user.info && user.info.name;

const age = user && user.info && user.info.getAge && user.info.getAge();
```

这是一种丑陋但又不得不做的前置校验，否则很容易命中 `Uncaught TypeError: Cannot read property...` 这种错误，这极有可能让你整个应用挂掉。

```javascript
const isExistName = user?.info?.name;

const age = user?.info?.getAge?.();
```

</details>

<details>
    <summary>空值合并运算符（Nullish coalescing Operator）</summary>

```javascript
const level = user.level || "暂无等级";

// 空字符串、0 ，当进行逻辑操作符判时，会自动转化为 false。在上面的代码里，如果玩家等级本身就是 0 级那就会有逻辑问题 有时候业务上，我们只需容错取值查询到 undefined 或者 null

// {
//    "level": null
// }
const level =
  user.level !== undefined && user.level !== null ? user.level : "暂无等级";
```

空值合并运算符 与 可选链 相结合，可以很轻松处理多级查询并赋予默认值问题

```javascript
const level = user.data?.level ?? "暂无等级";
```

</details>

<details>
    <summary>dynamic-import</summary>

按需 import 提案几年前就已提出，如今终于能进入 ES 正式规范。这里个人理解成“按需”更为贴切。现代前端打包资源越来越大，打包成几 M 的 JS 资源已成常态，而往往前端应用初始化时根本不需要全量加载逻辑资源，为了首屏渲染速度更快，很多时候都是按需加载，比如懒加载图片等。而这些按需执行逻辑资源都体现在某一个事件回调中去加载

```javascript
el.onclick = () => {
  import(`/path/current-logic.js`)
    .then((module) => {
      module.doSomthing();
    })
    .catch((err) => {
      // load error;
    });
};

// 配合webpack 注释 简直要起飞
async mounted() {
    const { FormulaEditorInstance } = await import(/* webpackChunkName: "formula-editor-base", webpackMode: "eager" */ './instance');
    this.editor = new FormulaEditorInstance(...)
}
```

</details>
</details>

<details>
    <summary>装饰器</summary>

[github](https://github.com/tc39/proposal-decorators)

`decorator`（装饰器）是 `ES7` 中的一个提案，目前处于 `stage-2` 阶段，提案地址：[JavaScript Decorators][https://github.com/tc39/proposal-decorators]。装饰器与之前讲过的函数组合（compose）以及高阶函数很相似。装饰器使用 @ 作为标识符，被放置在被装饰代码前面

装饰器接受 3 个参数

- target：被修饰的类
- name：类成员的名字
- descriptor：属性描述符，对象会将这个参数传给 Object.defineProperty 使用类属性装饰器可以做到很多有意思的事情

```javascript
function readonly(target, name, descriptor) {
  descriptor.writable = false;
  return descriptor;
}
class A {
  @readonly name = "vincent";
}
```

- 数据埋点
- 防抖节流
- 统计函数执行时间
- 数据格式验证

```javascript
const validate = (type) => (target, name) => {
  if (typeof target[name] !== type) {
    throw new Error(`attribute ${name} must be ${type} type`);
  }
};
class Form {
  @validate("string")
  name = 111; // Error: attribute name must be ${type} type
}
```

常用装饰器

- autobind：自动绑定 this，告别箭头函数和 bind
- readonly：将类属性设置为只读
- debounce：防抖函数
- throttle：节流函数
- enumerable：让一个类方法变得可枚举
- nonenumerable：让一个类属性变得不可枚举
- time：打印函数执行耗时

</details>
