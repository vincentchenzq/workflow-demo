"use strict";

require("core-js/modules/es.array.for-each");

require("core-js/modules/es.array.reduce");

require("core-js/modules/es.array.slice");

require("core-js/modules/es.object.get-own-property-descriptor");

require("core-js/modules/es.object.keys");

require("core-js/modules/web.dom-collections.for-each");

var _dec, _class;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

// function readonly(target, name, descriptor) {
//   descriptor.writable = false;
//   return descriptor;
// }
// class A {
//   @readonly name = "vincent";
// }
// const a = new A();
// a.name = "v"; // 报错
// =======================
// 添加静态属性
// const addProperty = (target) => {
//   target.isMan = true;
// };
// @addProperty
// class A {}
// console.log(A.isMan);
// =========================
var aop = function aop() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  return function (target, name, descriptor) {
    var method = descriptor.value;

    descriptor.value = function () {
      var _options$before, _options$after;

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      (_options$before = options.before) === null || _options$before === void 0 ? void 0 : _options$before.call(options, args);
      var val = method.apply(this, args);
      (_options$after = options.after) === null || _options$after === void 0 ? void 0 : _options$after.call(options, args);
      return val;
    };

    return descriptor;
  };
};

var A = (_dec = aop({
  before: function before() {
    console.log("before");
  },
  after: function after() {
    console.log("after");
  }
}), (_class = /*#__PURE__*/function () {
  function A() {
    _classCallCheck(this, A);
  }

  _createClass(A, [{
    key: "say",
    value: function say() {
      console.log("say");
    }
  }]);

  return A;
}(), (_applyDecoratedDescriptor(_class.prototype, "say", [_dec], Object.getOwnPropertyDescriptor(_class.prototype, "say"), _class.prototype)), _class));
new A().say(); // =================================
// var arr = [1, 2, [3, [4]]];
// class Bork {
//   // Private Fields
//   #xValue = 0;
//   a() {
//     this.#xValue++;
//   }
//   constructor(value) {
//     this.#xValue = value;
//     this.name = "vincent";
//   }
//   get x() {
//     return this.#xValue;
//   }
//   set x(value) {
//     this.#xValue = value;
//   }
// }
// const bork = new Bork(1);
// console.log(bork.x);
// bork.a();
// console.log(bork.x);
// console.log(arr.flat(Infinity));
