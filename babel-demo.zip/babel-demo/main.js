// function readonly(target, name, descriptor) {
//   descriptor.writable = false;
//   return descriptor;
// }
// class A {
//   @readonly name = "vincent";
// }

// const a = new A();
// a.name = "v"; // 报错

// =======================

// 添加静态属性
// const addProperty = (target) => {
//   target.isMan = true;
// };
// @addProperty
// class A {}
// console.log(A.isMan);

// =========================
const aop = (options = {}) => {
  return function (target, name, descriptor) {
    const method = descriptor.value;
    descriptor.value = function (...args) {
      options.before?.(args);
      const val = method.apply(this, args);
      options.after?.(args);
      return val;
    };
    return descriptor;
  };
};
class A {
  @aop({
    before() {
      console.log(`before`);
    },
    after() {
      console.log(`after`);
    },
  })
  say() {
    console.log(`say`);
  }
}
new A().say();
// =================================

// var arr = [1, 2, [3, [4]]];
// class Bork {
//   // Private Fields
//   #xValue = 0;
//   a() {
//     this.#xValue++;
//   }

//   constructor(value) {
//     this.#xValue = value;
//     this.name = "vincent";
//   }

//   get x() {
//     return this.#xValue;
//   }
//   set x(value) {
//     this.#xValue = value;
//   }
// }

// const bork = new Bork(1);
// console.log(bork.x);
// bork.a();
// console.log(bork.x);
// console.log(arr.flat(Infinity));
